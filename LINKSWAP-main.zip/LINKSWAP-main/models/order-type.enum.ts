export enum EOrderType {

  BUY,

  SELL

}