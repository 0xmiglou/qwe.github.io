export enum EOrderState {

  CREATED,
  
  CANCELLED,
  
  FINISHED

}